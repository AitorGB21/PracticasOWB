## Parte VI.3.  Ejercicio Práctico


Repositorio del Curso de jQuery desarrollado por @pekechis  para @OpenWebinars.
